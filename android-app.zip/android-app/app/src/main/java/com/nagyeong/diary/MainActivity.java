package com.nagyeong.diary;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * 나경이 일기 앱 화면.
 * 깃허브에 올린 나경이 일기(웹)를 웹뷰로 열고, 화면과 앱 사이에 연결 통로(NagyeongApp)를 놓는다.
 *  - 근무표가 바뀌면 화면이 updateWidget 을 불러 → 홈 화면 위젯이 저절로 바뀜
 *  - 사진·백업 파일 고르기, 백업 파일·사진 저장, 휴대폰 뒤로가기, 바깥 링크(전화·지도·Claude) 열기
 */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 11;
    private static final int REQ_SAVE = 12;

    private WebView web;
    private String appUrl;
    private ValueCallback<Uri[]> fileCallback;

    // 파일 저장 (한 번에 하나)
    private int nextSaveId = 1;
    private int pendingSaveId = 0;
    private int saveStreamId = 0;
    private OutputStream saveStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appUrl = getString(R.string.app_url);

        web = new WebView(this);
        web.setBackgroundColor(getColor(R.color.screen_bg));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.addJavascriptInterface(new Bridge(), "NagyeongApp");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.loadUrl(appUrl);
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        closeSave();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** 휴대폰 뒤로가기: 열린 창을 닫거나 이전 화면으로 (나경이 일기가 처리), 더 갈 곳이 없으면 앱 닫기 */
    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private boolean isAppPage(Uri u) {
        return u != null && u.toString().startsWith(appUrl);
    }

    /** 나경이 일기 밖의 주소(전화, 지도, Claude 등)는 휴대폰의 다른 앱으로 열기 */
    private void openExternal(String url) {
        try {
            Intent i = url.startsWith("intent:") ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "열 수 없는 주소예요", Toast.LENGTH_SHORT).show();
        }
    }

    private void showOffline() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;background:#FBF6F3;color:#2A2225;padding:48px 24px;text-align:center'>"
                + "<h2>💗 나경이 일기</h2><p style='line-height:1.7'>처음 한 번은 인터넷 연결이 필요해요.<br>"
                + "인터넷에 연결한 뒤 아래 버튼을 눌러 주세요.</p>"
                + "<p><a href='" + appUrl + "' style='display:inline-block;padding:14px 24px;border-radius:14px;"
                + "background:#D33F69;color:#fff;text-decoration:none;font-weight:bold'>다시 열기</a></p></body></html>";
        web.loadDataWithBaseURL(appUrl, html, "text/html", "utf-8", null);
    }

    private class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (isAppPage(u)) return false;
            openExternal(u.toString());
            return true;
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) showOffline();
        }
    }

    /** 사진·백업 파일 고르기 (<input type=file>) */
    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;

            List<String> mimes = new ArrayList<>();
            boolean hasExtension = false;
            String[] accept = params.getAcceptTypes();
            if (accept != null) {
                for (String a : accept) {
                    if (a == null) continue;
                    for (String part : a.split(",")) {
                        String t = part.trim();
                        if (t.isEmpty()) continue;
                        if (t.startsWith(".")) hasExtension = true;
                        else if (t.contains("/")) mimes.add(t);
                    }
                }
            }
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            if (!hasExtension && mimes.size() == 1) {
                i.setType(mimes.get(0));
            } else {
                i.setType("*/*");
                if (!hasExtension && mimes.size() > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
            }
            if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try {
                startActivityForResult(i, REQ_FILE);
            } catch (ActivityNotFoundException e) {
                fileCallback = null;
                Toast.makeText(MainActivity.this, "파일을 고를 수 있는 앱이 없어요", Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            Uri[] picked = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    picked = new Uri[clip.getItemCount()];
                    for (int k = 0; k < clip.getItemCount(); k++) picked[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    picked = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) fileCallback.onReceiveValue(picked);
            fileCallback = null;
            return;
        }
        if (requestCode == REQ_SAVE) {
            int id = pendingSaveId;
            pendingSaveId = 0;
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                synchronized (this) {
                    closeSaveLocked();
                    try {
                        saveStream = getContentResolver().openOutputStream(data.getData());
                        saveStreamId = id;
                        ok = saveStream != null;
                    } catch (Exception e) {
                        ok = false;
                    }
                }
            }
            web.evaluateJavascript("window.__appSaveReady && window.__appSaveReady(" + id + "," + ok + ")", null);
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private synchronized void closeSave() {
        closeSaveLocked();
    }

    private void closeSaveLocked() {
        if (saveStream != null) {
            try {
                saveStream.flush();
                saveStream.close();
            } catch (Exception ignored) {
                // 무시
            }
        }
        saveStream = null;
        saveStreamId = 0;
    }

    /** 나경이 일기 화면에서 부르는 연결 통로 (window.NagyeongApp) */
    private class Bridge {

        /** 근무표가 바뀔 때마다 화면이 보내 줌 → 저장하고 위젯 다시 그리기 */
        @JavascriptInterface
        public void updateWidget(String text) {
            if (ShiftData.parse(text) == null) return;
            Store.save(getApplicationContext(), text);
            ShiftWidget.updateAll(getApplicationContext());
        }

        @JavascriptInterface
        public int widgetCount() {
            return ShiftWidget.widgetCount(getApplicationContext());
        }

        @JavascriptInterface
        public boolean canPin() {
            return AppWidgetManager.getInstance(getApplicationContext()).isRequestPinAppWidgetSupported();
        }

        /** '홈 화면에 위젯 추가하기' */
        @JavascriptInterface
        public void pinWidget() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AppWidgetManager m = AppWidgetManager.getInstance(MainActivity.this);
                    if (m.isRequestPinAppWidgetSupported()) {
                        m.requestPinAppWidget(new ComponentName(MainActivity.this, ShiftWidget.class), null, null);
                    } else {
                        Toast.makeText(MainActivity.this, "홈 화면 빈 곳을 길게 누른 뒤 위젯 → 나경이 일기를 골라 주세요", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        /** 파일 저장 시작: 저장할 곳을 고르는 화면을 띄우고 번호를 돌려줌 (고르면 __appSaveReady 로 알려 줌) */
        @JavascriptInterface
        public int saveStart(final String name, final String mime) {
            final int id;
            synchronized (MainActivity.this) {
                id = nextSaveId++;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pendingSaveId = id;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    i.putExtra(Intent.EXTRA_TITLE, name == null ? "file" : name);
                    try {
                        startActivityForResult(i, REQ_SAVE);
                    } catch (ActivityNotFoundException e) {
                        pendingSaveId = 0;
                        web.evaluateJavascript("window.__appSaveReady && window.__appSaveReady(" + id + ",false)", null);
                    }
                }
            });
            return id;
        }

        /** 파일 조각 쓰기 (base64) */
        @JavascriptInterface
        public boolean saveChunk(int id, String base64) {
            synchronized (MainActivity.this) {
                if (saveStream == null || id != saveStreamId) return false;
                try {
                    saveStream.write(Base64.getDecoder().decode(base64));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        }

        /** 파일 저장 끝 */
        @JavascriptInterface
        public boolean saveEnd(int id) {
            boolean ok;
            synchronized (MainActivity.this) {
                ok = saveStream != null && id == saveStreamId;
                closeSaveLocked();
            }
            if (ok) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "저장했어요", Toast.LENGTH_SHORT).show();
                    }
                });
            }
            return ok;
        }
    }
}
