package com.nagyeong.diary;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.time.LocalDate;
import java.time.ZoneId;

/** 홈 화면 위젯: 오늘 근무 · 7일 근무 · 다음 쉬는 날 */
public class ShiftWidget extends AppWidgetProvider {

    static final String ACTION_TICK = "com.nagyeong.diary.TICK";

    private static final int[] CELL = {R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6};
    private static final int[] CELL_W = {R.id.d0_w, R.id.d1_w, R.id.d2_w, R.id.d3_w, R.id.d4_w, R.id.d5_w, R.id.d6_w};
    private static final int[] CELL_N = {R.id.d0_n, R.id.d1_n, R.id.d2_n, R.id.d3_n, R.id.d4_n, R.id.d5_n, R.id.d6_n};
    private static final int[] CELL_C = {R.id.d0_c, R.id.d1_c, R.id.d2_c, R.id.d3_c, R.id.d4_c, R.id.d5_c, R.id.d6_c};

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        RemoteViews v = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, v);
        scheduleTick(ctx);
    }

    @Override
    public void onEnabled(Context ctx) {
        scheduleTick(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(tickIntent(ctx));
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (ACTION_TICK.equals(intent.getAction())) updateAll(ctx);
    }

    /** 홈 화면의 모든 위젯을 새로 그림 */
    static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, ShiftWidget.class));
        if (ids != null && ids.length > 0) mgr.updateAppWidget(ids, build(ctx));
        scheduleTick(ctx);
    }

    static int widgetCount(Context ctx) {
        int[] ids = AppWidgetManager.getInstance(ctx).getAppWidgetIds(new ComponentName(ctx, ShiftWidget.class));
        return ids == null ? 0 : ids.length;
    }

    private static PendingIntent tickIntent(Context ctx) {
        Intent i = new Intent(ctx, ShiftWidget.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(ctx, 7, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** 자정이 지나면 '오늘'이 바뀌도록 다음 날 0시 1분에 다시 그리기 예약 */
    static void scheduleTick(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = LocalDate.now().plusDays(1).atStartOfDay().plusMinutes(1)
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        am.set(AlarmManager.RTC, at, tickIntent(ctx));
    }

    static int chipRes(String key) {
        switch (key == null ? "" : key) {
            case "sun": return R.drawable.chip_sun;
            case "orange": return R.drawable.chip_orange;
            case "rose": return R.drawable.chip_rose;
            case "violet": return R.drawable.chip_violet;
            case "navy": return R.drawable.chip_navy;
            case "teal": return R.drawable.chip_teal;
            case "green": return R.drawable.chip_green;
            default: return R.drawable.chip_gray;
        }
    }

    static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_shift);
        ShiftData d = Store.load(ctx);
        LocalDate today = LocalDate.now();
        int text = ctx.getColor(R.color.w_text);
        int muted = ctx.getColor(R.color.w_muted);
        int faint = ctx.getColor(R.color.w_faint);
        int sun = ctx.getColor(R.color.w_sun);
        int sat = ctx.getColor(R.color.w_sat);
        int accent = ctx.getColor(R.color.w_accent);

        String who = (d != null && !d.name.isEmpty()) ? d.name : "나경";
        v.setTextViewText(R.id.w_title, "💼 " + who + " 근무");
        v.setTextViewText(R.id.w_date, ShiftData.mdw(today));

        // 오늘
        String code = d == null ? null : d.code(today);
        ShiftData.Type t = d == null ? null : d.type(code);
        if (code != null) {
            String color = t == null ? "gray" : t.color;
            v.setTextViewText(R.id.w_today_chip, code + (t != null && !t.name.isEmpty() ? " " + t.name : ""));
            v.setInt(R.id.w_today_chip, "setBackgroundResource", chipRes(color));
            v.setTextColor(R.id.w_today_chip, ShiftData.colors(color)[1]);
            String time = ShiftData.timeLabel(t);
            v.setTextViewText(R.id.w_today_time, (t != null && t.off) ? "쉬는 날 💚" : time);
        } else {
            v.setTextViewText(R.id.w_today_chip, "?");
            v.setInt(R.id.w_today_chip, "setBackgroundResource", R.drawable.chip_gray);
            v.setTextColor(R.id.w_today_chip, 0xFFFFFFFF);
            v.setTextViewText(R.id.w_today_time, d == null ? "나경이 일기 앱에서 근무표를 넣어 주세요" : "오늘 근무는 아직 몰라요");
        }

        // 오늘부터 7일
        for (int i = 0; i < 7; i++) {
            LocalDate day = today.plusDays(i);
            int w = day.getDayOfWeek().getValue() % 7;   // 0 = 일요일
            v.setTextViewText(CELL_W[i], i == 0 ? "오늘" : String.valueOf(ShiftData.weekday(day)));
            v.setTextColor(CELL_W[i], i == 0 ? accent : muted);
            v.setTextViewText(CELL_N[i], String.valueOf(day.getDayOfMonth()));
            v.setTextColor(CELL_N[i], w == 0 ? sun : (w == 6 ? sat : text));
            v.setInt(CELL[i], "setBackgroundResource", i == 0 ? R.drawable.day_today : R.drawable.day_bg);
            String c = d == null ? null : d.code(day);
            ShiftData.Type ct = d == null ? null : d.type(c);
            if (c != null) {
                String color = ct == null ? "gray" : ct.color;
                v.setTextViewText(CELL_C[i], c);
                v.setInt(CELL_C[i], "setBackgroundResource", chipRes(color));
                v.setTextColor(CELL_C[i], ShiftData.colors(color)[1]);
            } else {
                v.setTextViewText(CELL_C[i], "·");
                v.setInt(CELL_C[i], "setBackgroundResource", R.drawable.chip_none);
                v.setTextColor(CELL_C[i], faint);
            }
        }

        // 아래 줄
        String foot;
        if (d == null) foot = "근무표를 아직 받지 않았어요";
        else if (!d.hasAny(today, 7)) foot = "이번 주 근무가 없어요 · 앱에서 근무표를 넣어 주세요";
        else foot = d.nextOffText(today);
        v.setTextViewText(R.id.w_footer, foot);

        // 위젯을 누르면 나경이 일기 앱 열기
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        v.setOnClickPendingIntent(R.id.root,
                PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return v;
    }
}
