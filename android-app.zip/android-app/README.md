# 나경이 일기 (안드로이드 앱)

깃허브 페이지에 올린 나경이 일기 화면을 여는 앱 + 홈 화면 근무표 위젯이에요.
설치·기록 옮기기 방법은 나경이 일기 README.md 의 「6. 📲 안드로이드 앱 + 홈 화면 위젯」 을 보세요.

- `app/src/main/java/com/nagyeong/diary/MainActivity.java` : 앱 화면(웹뷰), 사진·파일 고르기, 파일 저장, 뒤로가기, 위젯 연결 통로
- `ShiftWidget.java` : 홈 화면 위젯 그리기 (자정마다 '오늘' 갱신)
- `ShiftData.java` : 근무표 읽기 (순수 Java)
- `Store.java` : 받은 근무표 저장
- `app/src/main/res/layout/widget_shift.xml` : 위젯 모양
- `app.keystore` : 업데이트 설치에 필요한 서명 열쇠 (지우지 마세요)
- `test/ShiftDataTest.java` : 컴퓨터에서 돌리는 시험
- 앱이 여는 주소는 깃허브가 앱을 만들 때 저장소 이름으로 자동으로 넣어요 (`https://아이디.github.io/저장소이름/`)
