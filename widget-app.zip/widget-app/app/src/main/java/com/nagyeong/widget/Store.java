package com.nagyeong.widget;

import android.content.Context;
import android.content.SharedPreferences;

/** 받은 근무표를 휴대폰 안에 저장 */
final class Store {
    private static final String PREF = "shift_widget";

    private Store() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static void save(Context c, String text) {
        prefs(c).edit().putString("data", text).putLong("at", System.currentTimeMillis()).apply();
    }

    static ShiftData load(Context c) {
        return ShiftData.parse(prefs(c).getString("data", null));
    }

    static long savedAt(Context c) {
        return prefs(c).getLong("at", 0L);
    }
}
