package com.nagyeong.widget;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 나경이 일기에서 받은 근무표.
 * 안드로이드 기능을 쓰지 않는 순수 Java 라서 컴퓨터에서도 시험할 수 있다.
 *
 * 받는 글 형식 (줄마다 탭으로 나눔):
 *   NGW1
 *   name  나경
 *   url   https://아이디.github.io/our-days/
 *   sent  2026-11-03T07:40:00.000Z
 *   type  N  나이트  23:00  07:00  navy  0      ← 기호, 이름, 시작, 끝, 색, 쉬는날(1/0)
 *   day   2026-11-01  D
 */
public final class ShiftData {

    public static final class Type {
        public String code = "";
        public String name = "";
        public String start = "";
        public String end = "";
        public String color = "gray";
        public boolean off = false;
    }

    public String name = "";
    public String url = "";
    public String sent = "";
    public final Map<String, Type> types = new LinkedHashMap<>();
    public final Map<String, String> days = new HashMap<>();

    private static final String WEEK = "일월화수목금토";

    /** 글을 읽어서 근무표로. 형식이 틀리면 null */
    public static ShiftData parse(String text) {
        if (text == null) return null;
        String[] lines = text.replace("\r", "").split("\n");
        if (lines.length == 0 || !"NGW1".equals(lines[0].trim())) return null;
        ShiftData d = new ShiftData();
        for (int i = 1; i < lines.length; i++) {
            String[] p = lines[i].split("\t", -1);
            if (p.length < 2) continue;
            switch (p[0]) {
                case "name":
                    d.name = p[1].trim();
                    break;
                case "url":
                    d.url = p[1].trim();
                    break;
                case "sent":
                    d.sent = p[1].trim();
                    break;
                case "type":
                    if (p.length >= 7 && !p[1].trim().isEmpty()) {
                        Type t = new Type();
                        t.code = p[1].trim();
                        t.name = p[2].trim();
                        t.start = p[3].trim();
                        t.end = p[4].trim();
                        t.color = p[5].trim().isEmpty() ? "gray" : p[5].trim();
                        t.off = "1".equals(p[6].trim());
                        d.types.put(t.code, t);
                    }
                    break;
                case "day":
                    if (p.length >= 3 && p[1].matches("\\d{4}-\\d{2}-\\d{2}") && !p[2].trim().isEmpty()) {
                        d.days.put(p[1], p[2].trim());
                    }
                    break;
                default:
                    break;
            }
        }
        return d;
    }

    /** nagyeongwidget://import?d=… (또는 그 주소가 들어 있는 글)에서 근무표 글을 꺼냄. 없으면 null */
    public static String decodeLink(String raw) {
        if (raw == null) return null;
        int i = raw.indexOf("d=");
        if (i < 0) return null;
        String b64 = raw.substring(i + 2);
        int end = b64.length();
        for (int k = 0; k < b64.length(); k++) {
            char c = b64.charAt(k);
            boolean ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '=';
            if (!ok) { end = k; break; }
        }
        b64 = b64.substring(0, end);
        if (b64.isEmpty()) return null;
        try {
            byte[] bytes = Base64.getUrlDecoder().decode(b64);
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public String code(LocalDate day) {
        return days.get(day.toString());
    }

    public Type type(String code) {
        return code == null ? null : types.get(code);
    }

    /** from 날부터 maxDays 안의 첫 쉬는 날 (없으면 null) */
    public LocalDate nextOff(LocalDate from, int maxDays) {
        for (int i = 0; i <= maxDays; i++) {
            LocalDate d = from.plusDays(i);
            Type t = type(code(d));
            if (t != null && t.off) return d;
        }
        return null;
    }

    /** today 부터 n일 안에 근무가 하나라도 있는지 */
    public boolean hasAny(LocalDate today, int n) {
        for (int i = 0; i < n; i++) if (code(today.plusDays(i)) != null) return true;
        return false;
    }

    public static String timeLabel(Type t) {
        if (t == null || t.start.isEmpty() || t.end.isEmpty()) return "";
        return t.start + "~" + t.end + (t.end.compareTo(t.start) <= 0 ? " (다음 날)" : "");
    }

    public static char weekday(LocalDate d) {
        return WEEK.charAt(d.getDayOfWeek().getValue() % 7);
    }

    /** "11월 3일 (화)" */
    public static String mdw(LocalDate d) {
        return d.getMonthValue() + "월 " + d.getDayOfMonth() + "일 (" + weekday(d) + ")";
    }

    /** 다음 쉬는 날 안내 글. today 가 쉬는 날이면 내일부터 찾음 */
    public String nextOffText(LocalDate today) {
        Type t = type(code(today));
        LocalDate from = (t != null && t.off) ? today.plusDays(1) : today;
        LocalDate off = nextOff(from, 120);
        if (off == null) return "다음 쉬는 날: 근무표에 아직 없어요";
        long n = off.toEpochDay() - today.toEpochDay();
        String when = n == 0 ? "오늘" : n == 1 ? "내일" : n + "일 뒤";
        return "다음 쉬는 날: " + mdw(off) + " · " + when;
    }

    /** 색 이름 → [배경색, 글자색] (나경이 일기와 같은 색) */
    public static int[] colors(String key) {
        switch (key == null ? "" : key) {
            case "sun": return new int[]{0xFFFFC94D, 0xFF4A3200};
            case "orange": return new int[]{0xFFE36A24, 0xFFFFFFFF};
            case "rose": return new int[]{0xFFD9466F, 0xFFFFFFFF};
            case "violet": return new int[]{0xFF7B4FE0, 0xFFFFFFFF};
            case "navy": return new int[]{0xFF33449E, 0xFFFFFFFF};
            case "teal": return new int[]{0xFF138479, 0xFFFFFFFF};
            case "green": return new int[]{0xFF2E8B4A, 0xFFFFFFFF};
            default: return new int[]{0xFF6E6E78, 0xFFFFFFFF};
        }
    }

    /** 색 이름 → 둥근 배경 그림 이름 (res/drawable/chip_색.xml) */
    public static String chipName(String key) {
        switch (key == null ? "" : key) {
            case "sun": case "orange": case "rose": case "violet": case "navy": case "teal": case "green":
                return "chip_" + key;
            default:
                return "chip_gray";
        }
    }
}
