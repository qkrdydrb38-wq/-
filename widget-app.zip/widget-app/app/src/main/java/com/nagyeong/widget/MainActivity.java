package com.nagyeong.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;

/** 앱 화면: 나경이 일기에서 근무표 받기 + 위젯 추가 안내 */
public class MainActivity extends Activity {

    private String message = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btn_pin).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pinWidget(); }
        });
        findViewById(R.id.btn_open).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openDiary(); }
        });
        findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        if (savedInstanceState == null) handle(getIntent());
        render();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    /** 나경이 일기가 보낸 근무표 받기 */
    private void handle(Intent intent) {
        if (intent == null) return;
        String raw = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) raw = intent.getDataString();
        else if (Intent.ACTION_SEND.equals(intent.getAction())) raw = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (raw == null) return;
        String text = ShiftData.decodeLink(raw);
        ShiftData d = ShiftData.parse(text);
        if (d == null) {
            message = "받은 내용을 읽지 못했어요.\n나경이 일기에서 다시 '위젯으로 보내기'를 눌러 주세요.";
            return;
        }
        Store.save(this, text);
        ShiftWidget.updateAll(this);
        message = "✅ " + (d.name.isEmpty() ? "" : d.name + " ") + "근무표 " + d.days.size() + "일을 받았어요.\n홈 화면 위젯이 새 근무표로 바뀌었어요.";
        Toast.makeText(this, "근무표를 받았어요", Toast.LENGTH_SHORT).show();
    }

    private void render() {
        ShiftData d = Store.load(this);
        StringBuilder sb = new StringBuilder();
        if (message != null) sb.append(message).append("\n\n");
        if (d == null) {
            sb.append("아직 근무표를 받지 않았어요.\n나경이 일기 → 홈의 근무 카드 → '홈 화면 위젯 만들기'(또는 '위젯으로 보내기')를 눌러 주세요.");
        } else {
            LocalDate today = LocalDate.now();
            String code = d.code(today);
            ShiftData.Type t = d.type(code);
            sb.append("받은 근무: ").append(d.days.size()).append("일");
            long at = Store.savedAt(this);
            if (at > 0) sb.append("\n받은 때: ").append(DateFormat.format("yyyy.MM.dd HH:mm", at));
            sb.append("\n오늘: ");
            if (code == null) sb.append("근무 정보 없음");
            else sb.append(code).append(t != null && !t.name.isEmpty() ? " " + t.name : "");
            sb.append("\n").append(d.nextOffText(today));
        }
        ((TextView) findViewById(R.id.status)).setText(sb.toString());

        int n = ShiftWidget.widgetCount(this);
        ((TextView) findViewById(R.id.widget_status)).setText(
                n > 0 ? "홈 화면에 위젯이 " + n + "개 있어요 ✅" : "아직 홈 화면에 위젯이 없어요");
        Button pin = findViewById(R.id.btn_pin);
        pin.setText(n > 0 ? "위젯 하나 더 추가하기" : "홈 화면에 위젯 추가하기");
        pin.setVisibility(AppWidgetManager.getInstance(this).isRequestPinAppWidgetSupported() ? View.VISIBLE : View.GONE);
        findViewById(R.id.btn_open).setVisibility(d != null && d.url.startsWith("http") ? View.VISIBLE : View.GONE);
    }

    private void pinWidget() {
        AppWidgetManager m = AppWidgetManager.getInstance(this);
        if (m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(this, ShiftWidget.class), null, null);
        } else {
            Toast.makeText(this, "홈 화면 빈 곳을 길게 누른 뒤 위젯 → 나경이 근무 위젯을 골라 주세요", Toast.LENGTH_LONG).show();
        }
    }

    private void openDiary() {
        ShiftData d = Store.load(this);
        if (d != null && d.url.startsWith("http")) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(d.url)));
        }
    }
}
