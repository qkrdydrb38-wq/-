import com.nagyeong.widget.ShiftData;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;

/** 위젯 앱이 나경이 일기가 보낸 근무표를 제대로 읽는지 확인 (컴퓨터에서 실행) */
public class ShiftDataTest {
    static int pass = 0, fail = 0;
    static void check(String name, boolean ok, Object detail) {
        if (ok) { pass++; System.out.println("  ok   " + name); }
        else { fail++; System.out.println("  FAIL " + name + "  (" + detail + ")"); }
    }

    public static void main(String[] args) throws Exception {
        String link = new String(Files.readAllBytes(Paths.get(args[0])), StandardCharsets.UTF_8).trim();
        String expected = new String(Files.readAllBytes(Paths.get(args[1])), StandardCharsets.UTF_8);

        String text = ShiftData.decodeLink(link);
        check("주소에서 근무표 글 꺼내기 (웹 앱이 만든 그대로)", expected.equals(text), text == null ? "null" : text.length());
        String viaShare = ShiftData.decodeLink("나경이 근무 위젯\n" + link + "\n");
        check("공유로 받은 글에서도 꺼내기", expected.equals(viaShare), "");
        String viaIntent = ShiftData.decodeLink(link + "#Intent;scheme=nagyeongwidget;end");
        check("주소 뒤에 다른 글자가 붙어도 꺼내기", expected.equals(viaIntent), "");

        ShiftData d = ShiftData.parse(text);
        check("읽기 성공", d != null, "");
        check("이름 = 민지", "민지".equals(d.name), d.name);
        check("주소 = 나경이 일기", d.url.startsWith("http://localhost:8765/our-days/"), d.url);
        check("근무 종류 5개 (D E N O H)", String.join(",", d.types.keySet()).equals("D,E,N,O,H"), d.types.keySet());
        check("근무 날짜 11개", d.days.size() == 11, d.days.size());

        LocalDate oct15 = LocalDate.of(2026, 10, 15);
        ShiftData.Type n = d.type(d.code(oct15));
        check("10/15 = N 나이트", "N".equals(d.code(oct15)) && n != null && "나이트".equals(n.name), d.code(oct15));
        check("나이트 시간 = 22:00~07:00 (다음 날)", "22:00~07:00 (다음 날)".equals(ShiftData.timeLabel(n)), ShiftData.timeLabel(n));
        check("색 = 남색(navy)", "navy".equals(n.color) && ShiftData.colors(n.color)[0] == 0xFF33449E, n.color);
        check("다음 쉬는 날 (10/15 기준) = 10월 17일 (토) · 2일 뒤",
                "다음 쉬는 날: 10월 17일 (토) · 2일 뒤".equals(d.nextOffText(oct15)), d.nextOffText(oct15));
        LocalDate oct17 = LocalDate.of(2026, 10, 17);
        check("오늘이 쉬는 날이면 그다음 쉬는 날 (10/17 → 10/20 화 · 3일 뒤)",
                "다음 쉬는 날: 10월 20일 (화) · 3일 뒤".equals(d.nextOffText(oct17)), d.nextOffText(oct17));
        check("휴가(H)도 쉬는 날로 셈 (10/21)", d.type(d.code(LocalDate.of(2026, 10, 21))).off, "");
        check("요일 (2026-11-03 = 화)", ShiftData.weekday(LocalDate.of(2026, 11, 3)) == '화', "");
        check("날짜 글 (11월 3일 (화))", "11월 3일 (화)".equals(ShiftData.mdw(LocalDate.of(2026, 11, 3))), "");
        check("7일 안에 근무 있음 (10/15)", d.hasAny(oct15, 7), "");
        check("7일 안에 근무 없음 (12/10)", !d.hasAny(LocalDate.of(2026, 12, 10), 7), "");
        check("근무표 끝난 뒤 다음 쉬는 날 없음 안내",
                "다음 쉬는 날: 근무표에 아직 없어요".equals(d.nextOffText(LocalDate.of(2026, 12, 10))), "");
        check("근무 없는 날 = null", d.code(LocalDate.of(2026, 10, 19)) == null, "");

        // 잘못된 입력
        check("엉뚱한 글 → 읽지 않음", ShiftData.decodeLink("hello") == null && ShiftData.parse("hello") == null, "");
        check("빈 d= → 읽지 않음", ShiftData.decodeLink("nagyeongwidget://import?d=") == null, "");
        check("깨진 글자 → 읽지 않음", ShiftData.parse(ShiftData.decodeLink("nagyeongwidget://import?d=@@@")) == null, "");
        ShiftData odd = ShiftData.parse("NGW1\nday\t2026-13\tD\nday\t2026-11-01\t\ntype\t\tx\t\t\t\t0\nfoo\tbar\nday\t2026-11-02\tD");
        check("이상한 줄은 건너뜀", odd != null && odd.days.size() == 1 && odd.types.isEmpty(), odd == null ? "null" : odd.days);
        check("모르는 색은 회색", ShiftData.chipName("pink").equals("chip_gray") && ShiftData.chipName("teal").equals("chip_teal"), "");

        System.out.println("\n" + pass + "개 통과, " + fail + "개 실패");
        if (fail > 0) System.exit(1);
    }
}
