# 나경이 근무 위젯 (안드로이드)

나경이 일기의 근무표를 휴대폰 홈 화면 위젯으로 보여 주는 작은 앱이에요.
설치·연결 방법은 나경이 일기 README.md 의 「6. 📲 휴대폰 홈 화면 위젯」 을 보세요.

- `app/src/main/java/com/nagyeong/widget/ShiftData.java` : 받은 근무표 읽기 (순수 Java)
- `ShiftWidget.java` : 홈 화면 위젯 그리기 (자정마다 '오늘' 갱신)
- `MainActivity.java` : 근무표 받기 화면, 위젯 추가 버튼
- `app/src/main/res/layout/widget_shift.xml` : 위젯 모양
- `widget.keystore` : 업데이트 설치에 필요한 서명 열쇠 (지우지 마세요)
- `test/ShiftDataTest.java` : 컴퓨터에서 돌리는 시험
